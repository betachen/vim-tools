

typedef struct S_TestStruct1 {
   int one;
   int two;
} T_TestStruct1;


extern int my_func_1();
extern int my_func_2();

