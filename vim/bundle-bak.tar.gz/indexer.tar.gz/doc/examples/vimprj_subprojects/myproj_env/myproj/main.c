
int my_value = 5;

int my_func(void)
{
    return my_value;
}

int main(void)
{
    return my_func();
}

