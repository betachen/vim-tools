# Problems summary

## Expected

## Environment Information
 * OS:
 * Neovim/Vim/Gvim version:

## Provide a minimal .vimrc with less than 50 lines

    " Your minimal.vimrc

## Generate a logfile if appropriate

 1. export NVIM_PYTHON_LOG_FILE=/tmp/log
 2. export NVIM_PYTHON_LOG_LEVEL=DEBUG
 3. nvim -u minimal.vimrc
 4. recreate your issue
 5. cat /tmp/log_{PID}

## Screen shot (if possible)

## Upload the log file
